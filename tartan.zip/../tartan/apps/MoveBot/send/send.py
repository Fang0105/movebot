import serial
import time
import math

# Open serial connection to Arduino
ser = serial.Serial('/dev/serial0', 9600, timeout=1)
time.sleep(2)  # Wait for connection to establish


tt = 1

def send_a_number(number):
    ser.write((number + '\n').encode())

def send_angles(angles):
    global tt
    print(f"----------{tt}----------")
    tt = tt+1
    for num in angles:
        print(num)
        send_a_number(str(num))


f = open("output-paths/path.txt", mode="r")

f.readline()
f.readline()
f.readline()

all_angles = []

for line in f.readlines():
    if line == '\n':
        break
    else:
        all_angles.append(line.strip().split(' '))
        
all_angles = all_angles[::-1]
count = 0 
for angles in all_angles:
    count += 1
    send_angles(angles)
    time.sleep(1)
    if(count == 1):
        time.sleep(2)

time.sleep(5)

print("send 300!!")
send_a_number('300')
